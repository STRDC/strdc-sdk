# About the STRDC Drivers Library
The STRDC Drivers library abstracts HAL functions to make peripherals platform agnostic. This abstraction frees applications from hardware specific implementations, allowing developers to worry less about hardware and prototype faster. Intuitive examples are included to make getting started easy.
